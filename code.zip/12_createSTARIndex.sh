# input is output path, genome fa file and genome annotatio file

STAR \
--runThreadN 30 \
--runMode genomeGenerate \
--genomeDir $1 \
--genomeFastaFiles $2 \
--sjdbGTFfile $3 \
--sjdbOverhang 100
