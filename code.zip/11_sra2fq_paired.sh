# input is data path of paired reads, output path

for i in $(ls $1)
do      
	fastq-dump --split-3 $1/$i --outdir $2
done
