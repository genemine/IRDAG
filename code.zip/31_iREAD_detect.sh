# input is data path of bam file, intron bed file, and output path

for i in $(ls $1)
do
{
	# paired reads
	map_reads=$(samtools flagstat $1$i/Aligned.sortedByCoord.out.bam --threads 40|grep 'properly'|awk '{print $1}')

	if [ ! -d $3$i/ ];then
		mkdir -p $3$i/
	fi  

	iread.py $1$i/Aligned.sortedByCoord.out.bam $2 -o  $3$i/ -t $map_reads
}
done
wait
