path = '/home/zhengjt/wuzhenpeng/BIBM/' 
gtf =  path+'meta/transcripts.gtf'

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn:
        for l in fn: 
            l = l.split(sep)
            l[-1] = l[-1].split('\n')[0]
            read_data.append(l)
    return read_data[k:]

def read_gene(gtf):
    read_data = read_file(gtf,5)
    gene_data = []
    for l in read_data: 
        if l[2] != 'gene':
            continue
        else:
            gene_data.append(l)
    return gene_data

def convert_gene(gene_id,genes): # convert gene_id to gene_name
    gene_name = []
    for loc,val in enumerate(gene_id):
        for tl in genes:
            id = tl[8].split(';')[0].split('"')[1] # gene id
            if val == id:
                g  = tl[8].split(';')[2].split('"')[1] # gene name
                gene_name.append(g)
                break
    return gene_name

def backgroud_gene(gtf):
    gene_id_data = read_file('/home/zhengjt/wuzhenpeng/BIBM/BAM/SRR5305477/ReadsPerGene.out.tab', 4)
    gene_id = []
    for k in gene_id_data:
        gene_id.append(k[0])
    print(len(gene_id))

    genes_data = read_gene(gtf)
    genes = convert_gene(gene_id,genes_data)

    with open(path+'meta/backgroud_gene.txt', 'w') as bg:                                                                 
        for k in genes:
            bg.write(k+'\n')

backgroud_gene(gtf)
