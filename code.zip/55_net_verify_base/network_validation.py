# -*- coding: utf-8 -*-
import pandas as pd
from random import sample
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import mytools
from matplotlib.backends.backend_pdf import PdfPages


class GeneNet:
	def __init__(self,net_dir,diseaseGene_dir,weightThresholds=0):
		self.net_dir=net_dir
		self.weightThresholds=weightThresholds
		self.diseaseGenes=mytools.readList(diseaseGene_dir)

	def diseaseSubNet(self):
		wholeNet=pd.read_csv(self.net_dir,sep='\t',names=['a','b','w'])
		subNet=wholeNet[wholeNet.a.isin(self.diseaseGenes)|wholeNet.b.isin(self.diseaseGenes)]
		return subNet[subNet.w>self.weightThresholds]

class NetworkAnalysis():
	def __init__(self,net,diseaseGenes,predictGenes,allGenes,testTimes=10000):
		self.net=net
		self.predictGenes=predictGenes
		self.allGenes=allGenes
		self.testTimes=testTimes
		self.diseaseGenes=diseaseGenes

	def interactionAnalysis(self,genes):
		keepa=self.net.a.isin(genes) & self.net.b.isin(self.diseaseGenes)
		keepb=self.net.b.isin(genes) & self.net.a.isin(self.diseaseGenes)
		containGenesNet=self.net[keepa | keepb]
		n_edges=len(containGenesNet)
		genesInNet=list(self.net.a[keepa])+list(self.net.b[keepb])
		n_nodes=len(set(genesInNet))
		return n_nodes,n_edges

	def interactionTestAnalysis(self):
		n_genes=len(self.predictGenes)
		real_n_nodes,real_n_edges=self.interactionAnalysis(self.predictGenes)
		random_n_nodes=[]
		random_n_edges=[]
		for i in range(self.testTimes):
			random_genes=sample(self.allGenes,n_genes)
			random_n_node,random_n_edge=self.interactionAnalysis(random_genes)
			random_n_nodes.append(random_n_node)
			random_n_edges.append(random_n_edge)
		return real_n_nodes,real_n_edges,random_n_nodes,random_n_edges

	def networkInteractionValidation(self):
		def result_to_dict(real_v,random_list):
			n_bigger=sum([num>real_v for num in random_list])
			pv=float(n_bigger)/float(len(random_list))
			return {'real_value':real_v,'random_min':min(random_list),'random_mean':np.mean(random_list),'random_max':max(random_list),'pvalue':pv}
		real_n_nodes,real_n_edges,random_n_nodes,random_n_edges=self.interactionTestAnalysis()
		node_dict=result_to_dict(real_n_nodes,random_n_nodes)
		edge_dict=result_to_dict(real_n_edges,random_n_edges)
		result_df=pd.DataFrame({'interaction nodes':node_dict,'interaction edges':edge_dict}).reindex(['real_value','random_max','random_mean','random_min','pvalue'])
		return result_df,random_n_nodes,random_n_edges

	def strengthAnalysis(self,genes):
		keepa=self.net.a.isin(genes) & self.net.b.isin(self.diseaseGenes)
		keepb=self.net.b.isin(genes) & self.net.a.isin(self.diseaseGenes)
		if any(keepa | keepb):
			containGenesNet=self.net[keepa | keepb]
			return np.mean(containGenesNet.w.values)
		else:
			return 0.0

	def strengthTestAnalysis(self):
		n_genes=len(self.predictGenes)
		real_v=self.strengthAnalysis(self.predictGenes)
		random_strength=[]
		for i in range(self.testTimes):
			random_genes=sample(self.allGenes,n_genes)
			random_strength.append(self.strengthAnalysis(random_genes))
		return real_v,random_strength

	def networkInteractionStrengthValidation(self):
		def result_to_dict(real_v,random_list):
			n_bigger=sum([num>real_v for num in random_list])
			pv=float(n_bigger)/float(len(random_list))
			return {'real_value':real_v,'random_min':min(random_list),'random_mean':np.mean(random_list),'random_max':max(random_list),'pvalue':pv}
		real_v,random_strength=self.strengthTestAnalysis()
		rs_dict=result_to_dict(real_v,random_strength)
		result_df=pd.DataFrame({'interactionStrength':rs_dict}).reindex(['real_value','random_max','random_mean','random_min','pvalue'])
		return result_df,random_strength

def plotInteractions(n_nodes,ran_nodes,n_edges,ran_edges,cwd):
	if cwd[-1]!='/':
		cwd+='/'
	kinds=['interaction nodes','interaction edges']
	realv={'interaction nodes':n_nodes,'interaction edges':n_edges}
	ranv={'interaction nodes':ran_nodes,'interaction edges':ran_edges}
	font_size=13
	pdf=PdfPages(cwd+'interaction_with_known_disease_gene_in_functionNet.pdf')
	fig,axs=plt.subplots(1,2)
	plt.suptitle('Interaction with Known Disease Gene in FunctionNet')
	for i in [0,1]:
		kind=kinds[i]
		vc_random=pd.Series(ranv[kind]).value_counts()
		yy=vc_random.values
		xx=vc_random.index.values
		midy=max(yy)/2
		axs[i].bar(xx,yy,color='orange')
		axs[i].plot([realv[kind],realv[kind]],[0,midy],color='r')
		axs[i].spines['top'].set_visible(False)
		axs[i].spines['right'].set_visible(False)
		axs[i].spines['left'].set_visible(False)
		axs[i].tick_params(axis='x',labelsize=font_size)
		axs[i].patch.set_facecolor("gainsboro")
		axs[i].set_xlabel(kind)
	plt.setp(axs, yticks=[])
	plt.tight_layout(pad=3)
	pdf.savefig()
	plt.close()
	pdf.close()

def plotInteractionsStrength(real_v,ran_rcd,cwd):
	if cwd[-1]!='/':
		cwd+='/'
	pdf = PdfPages(cwd+'correlation_strength_with_disease_gene_in_functionNet.pdf')
	font_size=13
	font1 = {'size': font_size}
	#sns.set_style('dark')
	sns.despine(left=True)
	ran_rcd=np.array(ran_rcd,dtype='float')
	sns.distplot(ran_rcd, hist=False, color="orange",kde_kws={"shade": True})
	plt.plot([real_v,real_v],[0,100],color='r')
	plt.title('Correlation Strength with Disease Gene in FunctionNet',fontdict=font1)
	plt.tick_params(axis='x',labelsize=font_size)
	plt.yticks([])
	plt.tight_layout()
	pdf.savefig()
	plt.close()
	pdf.close()
