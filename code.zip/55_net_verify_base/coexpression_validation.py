# coding: utf-8
import numpy as np
from random import sample
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
from mytools import ProgressBar,readDict,readList
class CoExpression:
	def __init__(self, ex_df, samples_dict, prd_genes_list, disease_genes_list):
		self.ex_df=ex_df
		self.samples_dict=samples_dict
		self.prd_genes_list=prd_genes_list
		self.disease_genes_list=disease_genes_list
		self.disease_ex_df=ex_df.reindex(disease_genes_list)
	
	def coExpressionVald(self,val_grp,n_run):
		def removeAllZero(rpkm_df):
			all_zero=rpkm_df.apply(lambda x:all(x==0),axis=1)
			return rpkm_df[~ all_zero]
		def sub_ex_df(in_df,samples_dict,labels):
			useSamples=[]
			for k,v in samples_dict.items():
				if v in labels:
					useSamples.append(k)
			sub_in_df=in_df.reindex(columns=useSamples)
			return removeAllZero(sub_in_df)

		def eval_cor_core(dis_row,gene_ex):
			if dis_row.name==gene_ex.name:
				return np.nan
			else:
				return abs(dis_row.corr(gene_ex))
		def loopFun(prd_row,disease_ex_df):
			onePrd_allDis=disease_ex_df.apply(eval_cor_core,axis=1,gene_ex=prd_row)
			onePrd_allDis=onePrd_allDis[~onePrd_allDis.isna()]
			return np.mean(onePrd_allDis.values)
		def coExpressionKernel(sub_ex_df,disease_ex_df,prdG,disG):
			use_df=sub_ex_df.reindex(prdG).dropna()
			cor_df=use_df.apply(loopFun,axis=1,disease_ex_df=disease_ex_df)
			cor_df=cor_df[~cor_df.isna()]
			return np.mean(cor_df.values)
		grp_ex_df=sub_ex_df(self.ex_df,self.samples_dict,val_grp)
		allGenes=grp_ex_df.index.values
		grp_dis_df=sub_ex_df(self.disease_ex_df,self.samples_dict,val_grp)
		real_cor=coExpressionKernel(grp_ex_df,grp_dis_df,self.prd_genes_list,self.disease_genes_list)
		random_cors=[]
		bar=ProgressBar(total=n_run)
		for i in range(n_run):
			bar.move()
			bar.log()
			ranGenes=sample(list(allGenes),len(self.prd_genes_list))
			ranCor=coExpressionKernel(grp_ex_df,grp_dis_df,ranGenes,self.disease_genes_list)
			random_cors.append(ranCor)
		return real_cor,random_cors
	
	def coExpressWithinGenes(self,val_grp,n_run):
		def removeAllZero(rpkm_df):
			all_zero=rpkm_df.apply(lambda x:all(x==0),axis=1)
			return rpkm_df[~ all_zero]
		def sub_ex_df(in_df,samples_dict,labels):
			useSamples=[]
			for k,v in samples_dict.items():
				if v in labels:
					useSamples.append(k)
			sub_in_df=in_df.reindex(columns=useSamples)
			return removeAllZero(sub_in_df)
		def corrWithinGenes(ex_df,genes):
			noNAN_ex_df=ex_df.reindex(columns=genes).dropna(axis=1)
			cor_df=noNAN_ex_df.corr()
			abs_cor=abs(cor_df.values)
			cor_df_size=len(abs_cor)
			sum_corr=sum(sum(abs_cor-np.eye(cor_df_size)))
			mean_cor=sum_corr/(cor_df_size*(cor_df_size-1))
			return mean_cor
		grp_ex_df=sub_ex_df(self.ex_df,self.samples_dict,val_grp).T
		allGenes=grp_ex_df.columns.values
		real_cor=corrWithinGenes(grp_ex_df,self.prd_genes_list)
		random_cors=[]
		bar=ProgressBar(total=n_run)
		for i in range(n_run):
			bar.move()
			bar.log()
			ranGenes=sample(list(allGenes),len(self.prd_genes_list))
			ranCor=corrWithinGenes(grp_ex_df,ranGenes)
			random_cors.append(ranCor)
		return real_cor,random_cors



def plotCoExpression(real_v,ran_rcd,fig_path):
	pdf = PdfPages(fig_path)
	font_size=10
	font1 = {'size': font_size}
	fig,axs=plt.subplots(3,1)
	sub_titles=['In control expression matrix','In disease expression matrix','In control+disease expression matrix']
	for i in range(3):
		cax=axs[i]
		ran_rcd[i]=np.array(ran_rcd[i],dtype='float')
		sns.distplot(ran_rcd[i], hist=False, color="orange",kde_kws={"shade": True},ax=cax)
		cax.plot([real_v[i],real_v[i]],[0,100],color='r')
		cax.set_title(sub_titles[i],fontdict=font1)
		cax.set_yticks([])
	plt.suptitle('co-expression between predict gene and known gene')
	plt.tight_layout(pad=2)
	pdf.savefig()
	plt.close()
	pdf.close()
