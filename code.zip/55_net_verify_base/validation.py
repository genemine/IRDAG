# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 20:01:07 2019

@author: lws
"""
import click
import os
import pandas as pd
import numpy as np 
from multiprocessing import Pool
import mytools
import coexpression_validation
import network_validation
import comiRNA_validation

def cal_pv(realv,ranvs):
	rs={}
	rs['pvalue']=float(sum(pd.Series(ranvs)>realv))/float(len(ranvs))
	rs['random_max']=max(ranvs)
	rs['random_mean']=np.mean(ranvs)
	rs['random_min']=min(ranvs)
	rs['real_value']=realv
	return rs

@click.group()
def cli():
	pass
@cli.command()
@click.option('-d','--output-directory',required=True,help='validation output directory')
@click.option('--net',required=True,help='path of network')
@click.option('--ag',required=True,help='path of all gene list')
@click.option('--dg',required=True,help='path of known disease gene list')
@click.option('--pg',required=True,help='path of predict gene list')
@click.option('-t',required=True,type=int,help='type of validation(0 or 1): \n0:count interaction nodes and edges. \n1:calculate interaction strength. ')
@click.option('-n',type=int,default=10000,show_default=True,help='random test times')
@click.option('-w',type=float,default=0.0,show_default=True,help='(value from 0 to 1)threshold of significant interaction between two genes')
@click.pass_context
def NW(ctx,output_directory,net,ag,dg,pg,t,n,w):
	'''
	(network validation) validation of interaction between predict and knwon genes in network
	'''
	if output_directory[-1]!='/':
		output_directory+='/'
	output_directory+='network_validation/'
	if not os.path.exists(output_directory):
		os.mkdir(output_directory)
	if(t==0):
		geneNet=network_validation.GeneNet(net,dg,weightThresholds=w)
		subGeneNet=geneNet.diseaseSubNet()
		prdGenes=mytools.readList(pg)
		allGenes=mytools.readList(ag)
		netanalysis=network_validation.NetworkAnalysis(subGeneNet,geneNet.diseaseGenes,prdGenes,allGenes,testTimes=n)
		df,node_record,edge_record=netanalysis.networkInteractionValidation()
		network_validation.plotInteractions(df['interaction nodes']['real_value'],node_record,df['interaction edges']['real_value'],edge_record,output_directory)
		df.to_csv(output_directory+'interactionWithDiseaseGeneInNetwork.tsv',sep='\t')
	elif t==1:
		geneNet=network_validation.GeneNet(net,dg,weightThresholds=w)
		subGeneNet=geneNet.diseaseSubNet()
		prdGenes=mytools.readList(pg)
		allGenes=mytools.readList(ag)
		netanalysis=network_validation.NetworkAnalysis(subGeneNet,geneNet.diseaseGenes,prdGenes,allGenes,testTimes=n)
		strength_df,randomlist=netanalysis.networkInteractionStrengthValidation()
		network_validation.plotInteractionsStrength(cwd=output_directory,ran_rcd=randomlist,real_v=strength_df.interactionStrength['real_value'])
		strength_df.to_csv(output_directory+'interactionStrengthWithDiseaseGeneInNetwork.tsv',sep='\t')
	else:
		print('error: please let -t be 0 or 1')
	print('[Done] result stored in '+output_directory)

@cli.command()
@click.option('-d','--output-directory',required=True,help='validation output directory')
@click.option('-s',required=True,help='path of samples dict to clarify samples is control(0) or disease(1)')
@click.option('--dg',required=True,help='path of known disease gene list')
@click.option('--pg',required=True,help='path of predict gene list')
@click.option('-n',type=int,default=100,show_default=True,help='random test times(it may take a long time)')
@click.option('--exps',required=True,help='path of gene expression matrix')
@click.pass_context
def CX(ctx,output_directory,s,dg,pg,n,exps):
	'''
	(co-expression validation) validation of correlation between predict and knwon genes in expression matrix
	'''
	if output_directory[-1]!='/':
		output_directory+='/'
	output_directory+='co-expression_validation/'
	if not os.path.exists(output_directory):
		os.mkdir(output_directory)
	ex_df=pd.read_csv(exps,sep='\t',index_col=0)
	samples_dict=mytools.readDict(s)
	prdG=mytools.readList(pg)
	disG=mytools.readList(dg)
	ce=coexpression_validation.CoExpression(ex_df,samples_dict,prdG,disG)
	pool=Pool(processes=6)
	rsa0=pool.apply_async(ce.coExpressionVald,([0],n)) #in control expression matrix
	rsa1=pool.apply_async(ce.coExpressionVald,([1],n)) #in disease expression matrix
	rsa01=pool.apply_async(ce.coExpressionVald,([0,1],n)) #in control+disease expression matrix
	
	rsb0=pool.apply_async(ce.coExpressWithinGenes,([0],n)) # control
	rsb1=pool.apply_async(ce.coExpressWithinGenes,([1],n)) # disease
	rsb01=pool.apply_async(ce.coExpressWithinGenes,([0,1],n)) # control+disease
	pool.close()
	pool.join()
	def resultProcess(rs0,rs1,rs01,description):
		real_v0,random_rcd0=rs0.get()
		real_v1,random_rcd1=rs1.get()
		real_v01,random_rcd01=rs01.get()
		coexpression_validation.plotCoExpression([real_v0,real_v1,real_v01],[random_rcd0,random_rcd1,random_rcd01],output_directory+description+'.pdf')
		rs0=cal_pv(real_v0,random_rcd0)
		rs1=cal_pv(real_v1,random_rcd1)
		rs01=cal_pv(real_v01,random_rcd01)
		rs_dict={'control expression matrix':rs0,'disease expression matrix':rs1,'control+disease expression matrix':rs01}
		rs_df=pd.DataFrame(rs_dict).reindex(['real_value','random_max','random_mean','random_min','pvalue'])
		rs_df.to_csv(output_directory+description+'.tsv',sep='\t')
	resultProcess(rsa0,rsa1,rsa01,'co-expressionWithDiseaseInExpressionProfile')
	resultProcess(rsb0,rsb1,rsb01,'genesCo-expressionInExpressionProfile')
	print('[Done] result stored in '+output_directory)

@cli.command()
@click.option('-d','--output-directory',required=True,help='validation output directory')
@click.option('-m',required=True,help='path of miRNA-Gene association file')
@click.option('--dg',required=True,help='path of known disease gene list')
@click.option('--pg',required=True,help='path of predict gene list')
@click.option('--ag',required=True,help='path of all gene list')
@click.option('-n',type=int,default=100,show_default=True,help='random test times')
@click.pass_context
def CM(ctx,output_directory,m,dg,pg,ag,n):
	'''
	(co-miRNA validation) validation of co-miRNA between predict and knwon genes
	'''
	if output_directory[-1]!='/':
		output_directory+='/'
	output_directory+='co-miRNA_validation/'
	if not os.path.exists(output_directory):
		os.mkdir(output_directory)
	db=pd.read_csv(m,sep='\t')
	prdG=mytools.readList(pg)
	disG=mytools.readList(dg)
	allG=mytools.readList(ag)
	cm=comiRNA_validation.CoMiRNA(db,prdG,disG,allG)
	pool=Pool(processes=2)
	rs0=pool.apply_async(cm.coMiRNA,(n,))
	rs1=pool.apply_async(cm.top3CoMiRNA,(n,))
	pool.close()
	pool.join()
	# validation 1
	realv,ranv=rs0.get()
	rs0=cal_pv(realv,ranv)
	rs0={'co-miRNA':rs0}
	pd.DataFrame(rs0).to_csv(output_directory+'co-miRNAWithDiseaseGene.tsv',sep='\t')
	comiRNA_validation.plotCoMiRNA(realv,ranv,output_directory+'co-miRNAWithDiseaseGene.pdf')
	# validation 2
	realdict,randict=rs1.get()
	rs_dict={}
	for k in realdict.keys():
		rs_dict[k]=cal_pv(realdict[k],randict[k])
	rs_df=pd.DataFrame(rs_dict).reindex(['real_value','random_max','random_mean','random_min','pvalue'])
	rs_df.to_csv(output_directory+'targetGeneOfTop3DiseaseGeneMiRNA.tsv',sep='\t')
	comiRNA_validation.plotTop3ComiRNA(realdict,randict,output_directory+'targetGeneOfTop3DiseaseGeneMiRNA.pdf')
	print('[Done] result stored in '+output_directory)
if __name__ == '__main__':
	cli(obj={})