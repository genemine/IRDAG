#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 29 18:49:18 2019

@author: lws
"""
import pandas as pd
from random import sample
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
class CoMiRNA:
	def __init__ (self,db,prdGenes,disGenes,allGenes):
		self.db=db
		self.disMiRNA=set(db['miRNA'][db['Target Gene'].isin(disGenes)].values)
		self.prdGenes=prdGenes
		self.disGenes=disGenes
		self.allGenes=allGenes
		self.top3=(db['miRNA'][db['Target Gene'].isin(disGenes)]).value_counts().index.values[:3]
	def coMiRNA(self,n_run):
		def cal_n_coMiRNA(givenGenes,db,disMiRNA):
			aimMiRNAs=set(db['miRNA'][db['Target Gene'].isin(givenGenes)].values)
			return len(aimMiRNAs & disMiRNA)
		real_value = cal_n_coMiRNA(self.prdGenes,self.db,self.disMiRNA)
		n_prd=len(self.prdGenes)
		random_record=[]
		for i in range(n_run):
			randomGenes=sample(self.allGenes,n_prd)
			random_n_coMiRNA=cal_n_coMiRNA(randomGenes,self.db,self.disMiRNA)
			random_record.append(random_n_coMiRNA)
		return real_value,random_record
	def top3CoMiRNA(self,n_run):
		def cal_n_top3CoMiRNA(givenGenes,topMiRNA,db):
			sub_db=self.db[self.db['miRNA']==topMiRNA]
			return sum(sub_db['Target Gene'].isin(givenGenes))
		real_dict={}
		random_dict={}
		for mi in self.top3:
			real_dict[mi]=cal_n_top3CoMiRNA(self.prdGenes,mi,self.db)
			rcd=[]
			for i in range(n_run):
				randomGenes=sample(self.allGenes,len(self.prdGenes))
				rcd.append(cal_n_top3CoMiRNA(randomGenes,mi,self.db))
			random_dict[mi]=rcd
		return real_dict,random_dict

def plotCoMiRNA(real_v,ran_rcd,fig_path):
	pdf = PdfPages(fig_path)
	font_size=13
	font1 = {'size': font_size}
	#sns.set_style('dark')
	sns.despine(left=True)
	vc_random=pd.Series(ran_rcd).value_counts()
	yy=vc_random.values
	xx=vc_random.index.values
	midy=max(yy)/2
	plt.bar(xx,yy,color='orange')
	plt.plot([real_v,real_v],[0,midy],color='r')
	plt.title('co-miRNA',fontdict=font1)
	plt.tick_params(axis='x',labelsize=font_size)
	plt.yticks([])
	plt.tight_layout()
	pdf.savefig()
	plt.close()
	pdf.close()

def plotTop3ComiRNA(realdict,randict,fig_path):
	font_size=13
	pdf=PdfPages(fig_path)
	fig,axs=plt.subplots(3,1)
	plt.suptitle('target gene of top3 disease gene miRNA')
	keys=list(realdict.keys())
	for i in range(3):
		k=keys[i]
		vc_random=pd.Series(randict[k]).value_counts()
		yy=vc_random.values
		xx=vc_random.index.values
		midy=max(yy)/2
		axs[i].bar(xx,yy,color='orange')
		axs[i].plot([realdict[k],realdict[k]],[0,midy],color='r')
		axs[i].spines['top'].set_visible(False)
		axs[i].spines['right'].set_visible(False)
		axs[i].spines['left'].set_visible(False)
		axs[i].tick_params(axis='x',labelsize=font_size)
		axs[i].patch.set_facecolor("gainsboro")
		axs[i].set_xlabel(k)
	plt.setp(axs, yticks=[])
	plt.tight_layout(pad=1)
	pdf.savefig()
	plt.close()
	pdf.close()


