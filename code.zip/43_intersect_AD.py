path = '/home/zhengjt/wuzhenpeng/BIBM/DE_file_single/'
file1 = '/home/zhengjt/wuzhenpeng/BIBM/meta/AD_relate_gene.txt'
file2 = path+'iREAD_edgeR.txt'
file3 =  path+'IRFinder_t_test.txt'
file4 = path+'traditional_edgeR.txt'
gtf =  '/home/zhengjt/wuzhenpeng/BIBM/meta/transcripts.gtf'

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn:
        for l in fn: 
            l = l.split(sep)
            l[-1] = l[-1].split('\n')[0]
            read_data.append(l)
    return read_data[k:]

def write_file(file,genes,k=0):
    if k == 0:
        k = len(genes)
    with open(file,'w') as idge:
        for g in genes[0:k]:
            idge.write(g+'\n')

def read_gene(gtf):
    read_data = read_file(gtf,5)
    gene_data = []
    for l in read_data: 
        if l[2] != 'gene':
            continue
        else:
            gene_data.append(l)
    return gene_data

def convert_gene(gene_id,genes): # convert gene_id to gene_name
    gene_name = ['NA'] * len(gene_id)
    for loc,val in enumerate(gene_id):
        for tl in genes:
            id = tl[8].split(';')[0].split('"')[1] # gene id
            if val == id:
                gene_name[loc] = tl[8].split(';')[2].split('"')[1] # gene name
                break
    return gene_name


def remove_duplicates(l):
    newlist = []
    for s in l:
        if s not in newlist:
            newlist.append(s)
    return newlist

def get_half_prior(l1,l2):
    newList = []
    m = len(l1)
    n = len(l2)
    length = min(m,n)
    for s in range(length):
        if l1[s] not in newList:
            newList.append(l1[s])
        if l2[s] not in newList:
            newList.append(l2[s])

    if length >= m:
        for k in l2[length:n]:
            if k not in newList:
                newList.append(k)
    if s >= n:
        for k in l1[length:m]:
            if k not in newList:
                newList.append(k)

    return newList

def DEG_AD_intersect(file1,file2,file3,file4,gtf): #1AD;2iREAD;3IRFinder;4traditional;5gtf
    DEG_primer_1 = read_file(file2,1)
    DEG_primer_2 = read_file(file3,1)
    DEG_primer_3 = read_file(file4,1)

    iREAD_id = []
    for k in DEG_primer_1:
        iREAD_id.append(k[0].split('-')[3])
    IRFinder_id = []
    for k in DEG_primer_2:
        IRFinder_id.append(k[0].split(';')[2].split('/')[1])
    traditional_id = []
    for k in DEG_primer_3:
        traditional_id.append(k[0])
    
    iREAD_id = remove_duplicates(iREAD_id)
    IRFinder_id = remove_duplicates(IRFinder_id)
    traditional_id = remove_duplicates(traditional_id)

    genes = read_gene(gtf)
    iREAD = convert_gene(iREAD_id, genes)
    IRFinder = convert_gene(IRFinder_id, genes)

    print('iREAD -> ',len(iREAD))
    print('IRFinder -> ',len(IRFinder))

    tr = convert_gene(traditional_id, genes)

    union_method = get_half_prior(iREAD, IRFinder)

    AD_file = read_file(file1)
    AD = []
    for l in AD_file: 
        AD.append(l[0])
    
    inter_tr = set(tr) & set(AD)
    inter_union = set(union_method) & set(AD)
    inter_tr_u = set(union_method) &  set(tr)

    print( len(set(tr)), 'tr number: ', len(inter_tr) )
    print( len(set(union_method)), 'union_method number: ', len(inter_union) )
    print( len(set(union_method)), len(set(tr)),  'tr_u_number: ', len(inter_tr_u) )

    print( 'tr result: ', sorted(inter_tr) )
    print( 'union_method result: ', sorted(inter_union) )
    #print( 'tr_u result: ', inter_tr_u )

    tr_u_AD = inter_tr & inter_union
    print('tr_intr_AD',len(tr_u_AD),tr_u_AD)

    # write diff_gene for downstream analysis
    write_file(path+'traditional_DE_name'+'_100.txt',tr,100) 
    write_file(path+'traditional_DE_name'+'_300.txt',tr,300) 
    write_file(path+'traditional_DE_name'+'_500.txt',tr,500)
    write_file(path+'traditional_DE_name.txt',tr,0) # all genes

    write_file(path+'IRDAG_DE_name'+'_100.txt',union_method,100) 
    write_file(path+'IRDAG_DE_name'+'_300.txt',union_method,300)
    write_file(path+'IRDAG_DE_name'+'_500.txt',union_method,500)
    write_file(path+'IRDAG_DE_name.txt',union_method,0) # all genes

DEG_AD_intersect(file1,file2,file3,file4,gtf)

