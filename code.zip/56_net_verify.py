import os

ppi_net = './data_PPI/links.txt'
brain_net = './data_FGN/brain_FGN_weight.txt'
path = 'DE_file_single'

def verify_net(net, pg, num, w, out):
    command =  "python3 ./55_net_verify_base/validation.py nw -d "+out+" --net "+net+" --ag ./meta/backgroud_gene.txt --pg "+pg+" --dg ./meta/AD_relate_gene.txt -t 0 -n "+num+" -w "+w
    #print(command)
    os.system(command)

def verify(ppi_net,brain_net):
    num = '1000000' # number of sampling: 1e6
    for m in ['IRDAG','traditional']:
        for k in ['100','300']:
            pg = './'+path+'/'+m+'_DE_name_'+k+'.txt'
            ppi_out = './'+path+'_verify/ppi/'+m+'/top'+k
            FGN_out = './'+path+'_verify/FGN/'+m+'/top'+k
            if not os.path.isdir(ppi_out):
                os.makedirs(ppi_out)
            if not os.path.isdir(FGN_out):
                os.makedirs(FGN_out)
            verify_net(ppi_net, pg, num, '0', ppi_out)
            verify_net(brain_net, pg, num, '0.80', FGN_out)

verify(ppi_net,brain_net)
