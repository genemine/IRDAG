source /home/zhengjt/wuzhenpeng/anaconda3/bin/activate wzp_r              
Rscript $1
