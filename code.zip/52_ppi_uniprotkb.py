file = './PPI_data/PPI_database_MINT.txt'
out = './PPI_data/ppi_uniprotkb.txt'

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn: 
        for l in fn: 
            l = l.split(sep)
            read_data.append(l)
    return read_data[k:]

def convert_format(file):
    ppi = read_file(file,0)
    l_ppi = len(ppi)
    intersection = [[] for i in range(l_ppi)]

    i = 0
    for l in ppi:
        A = l[0].split(':')
        B = l[1].split(':')
        if len(A) != 2 or len(B) != 2:
            i += 1
            continue
        intersection[i].append(A[1])
        intersection[i].append(B[1])
        i += 1
        
    with open(out, 'w') as ou:
        for l in intersection:
            if len(l) == 2 and l[0] != l[1]:
                ou.write(l[0]+' '+l[1]+'\n')

convert_format(file)
