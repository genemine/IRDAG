import os    
import optparse
import numpy as np

optParser = optparse.OptionParser()
(opts, args) = optParser.parse_args()

# the input is read counts of star and output path
in_path = args[0]
out_path = args[1]
sep = '\t'

def get_files(path,type):
    files = []
    for file in os.listdir(path):  
        file_path = os.path.join(path, file)  
        files.append(file_path+'/'+type)
    return files

def read_file(filename,k):
    read_data = []
    with open(filename,'r') as fn: 
        for l in fn: 
            l = l.split(sep)
            read_data.append(l)
    return read_data[k:]

def get_read_counts(path):
    files = get_files(path,'ReadsPerGene.out.tab')
    read_counts = {}
    for file in files:
        id = file.split('/')[-2]
        tk_data = read_file(file,4)
        read_counts[id] = tk_data
    return read_counts

def merge_read_counts(in_path,out_path,strand = 1): # '1' is unstrand, '2' is 1st strand, '3' is 2st strand
    read_counts = get_read_counts(in_path)

    files = []
    for srr_id in os.listdir(in_path):
        files.append(srr_id)
    files=  sorted(files)

    tmp = read_counts[files[0]]
    genes = []
    for l in tmp:
        genes.append(l[0])

    merge_counts = np.zeros( ( len(genes), len(files) ) )
    for id,file in enumerate(files):
        tk_data = read_counts[file]
        num = len(tk_data)
        for key,val in enumerate(tk_data):
            merge_counts[key,id] = val[strand]
    
    # write final read counts
    with open(out_path+'traditional_read_counts.txt','w') as r_c:
        first_line = ['gene_id/sample']
        for file_key in files:
            first_line.append(file_key)
        first_line = sep.join(first_line) 
        r_c.write(first_line+'\n')

        for id,row in enumerate(merge_counts):
            tl = [ genes[id] ]                
            for data in row:
                tl.append( str( int(data) ) ) 
            tl = sep.join(tl)
            r_c.write(tl+'\n')

merge_read_counts(in_path,out_path)
