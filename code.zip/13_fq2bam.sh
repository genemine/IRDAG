# input is path sequencing data, output path, building index of STAR and layout
# layout: single or paired

if [ $4 = "paired" ];then
    bash fq2bam_paired.sh $1 $2 $3
elif [ $4 = "single" ];then
    bash fq2bam_single.sh $1 $2 $3
else
    echo 'the layout is not correct, layout should be single or paired!'
fi
