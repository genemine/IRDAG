# input is data path of single reads, output path and building index of STAR

ulimit -n 10000

for i in $(ls $1)
do
{
	if [ ! -d $2${i%.*}/ ];then
		mkdir -p $2${i%.*}/
    fi
        
        
    STAR    --runThreadN 40 \
    	--readFilesIn $1$i \
		--quantMode TranscriptomeSAM GeneCounts \
    	--sjdbFileChrStartEnd $3sjdbList.out.tab \
    	--genomeDir $3 \
		--outSAMtype BAM Unsorted SortedByCoordinate \
	    --outFileNamePrefix $2${i%.*}/

}
done
wait
