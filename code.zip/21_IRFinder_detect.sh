# input is data path of bam file, building index of IRFinder and output path

for i in $(ls $1)
do
{
	if [ ! -d $3$i/ ];then
		mkdir -p $3$i/
	fi 

	IRFinder -m BAM -r $2 -d $3$i/ $1$i/Aligned.out.bam 
}
done
wait
