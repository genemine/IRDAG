library("edgeR")

path =  "/home/zhengjt/wuzhenpeng/BIBM/DE_file_single/"
setwd(path)

x <- read.table("iREAD_read_counts.txt", sep = "\t", header = TRUE, row.names = 1)

covariates <- read.table("design.txt", sep = "\t", header = F, row.names = 1)

fdr <- 0.05
log_FC <- 1.0

libsize <- as.numeric( unlist( read.table("iREAD_libsize.txt") ) )

y <- DGEList(counts = x, lib.size = libsize) 

keep <- rowSums(cpm(y)>1) >= 2
y <- y[keep,]

y <- calcNormFactors(y, method = "TMM")

group <- covariates$V2
sexs <- covariates$V3
ages <- covariates$V4

design <- model.matrix(~group+sexs+ages) # Adjusting for confounding factor
rownames(design) <- colnames(y)
#design

y <- estimateGLMCommonDisp(y, design, verbose=TRUE)
y <- estimateGLMTrendedDisp(y, design)
y <- estimateGLMTagwiseDisp(y, design)

fit <- glmFit(y, design)
lrt <- glmLRT(fit,coef=2)

top <- topTags(lrt, n = nrow(y$counts), adjust.method="BH")

#summary(de <- decideTestsDGE(et))
#detags <- rownames(y)[as.logical(de)]

allDiff <- top$table
diff <- allDiff[is.na(allDiff$FDR)==FALSE,]

index = diff$FDR < fdr# & abs(diff$logFC) >= log_FC
diffSig <- diff[index,]
write.table(diffSig, "iREAD_edgeR.txt", quote = FALSE, sep = '\t')

