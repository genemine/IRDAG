import os 
import optparse
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf 

optParser = optparse.OptionParser()
(opts, args) = optParser.parse_args()

data = args[0]
design = args[1]
output = args[2]

#data = 'IRFinder_IR_Ratio.txt'
#design = 'design.txt'
#output = './'

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn: 
        for l in fn: 
            l = l.split(sep)
            l[-1] = l[-1].split('\n')[0]
            read_data.append(l)
    return read_data[k:]

def sim_test(sample,conditions,sexs,ages): 
    id = sample[0]
    sample =  sample[1:] # IR ratio
    with  open('IR_tmp.csv', 'w') as it:
        it.write(',conditions,sexs,ages,IR_ratio'+'\n')
        for i,k in enumerate(sample):
            if conditions[i] == 'AD':
                g = 0
            else:
                g = 1
            if sexs[i] == 'male':
                s = 0
            else:
                s = 1
            ratio = np.log2(1+float(sample[i]))
            it.write(str(i)+','+str(g)+','+str(s)+','+ages[i]+','+str(ratio)+'\n') 

    df = pd.read_csv("IR_tmp.csv")
#    X = df[['conditions', 'sexs', 'ages']]
#    Y = df['IR_ratio']
    
    est = smf.ols(formula='IR_ratio~conditions+sexs+ages', data=df).fit() # adjust covariate
    result = str(est.summary()).split('conditions')[1].split('sexs')[0].split(' ')
    sig = list(filter(None, result))[3] # p-value of t-test
    return id,sig

def all_test(data,design):
    ds = read_file(design) # design, for model 
    conditions = []
    sexs = []
    ages = []
    for k in ds:
        conditions.append(k[1])
        sexs.append(k[2])
        ages.append(k[3])

    ss = read_file(data)
    ss = ss[1:]
    sigs = []
    ids = []
    for k in ss: # per IR event
        id,sig = sim_test(k,conditions,sexs,ages)
        ids.append(id)
        sigs.append(sig)
    
    os.system('rm IR_tmp.csv')
    with open(output+'IRFinder_p_value.txt','w') as itv:
        for i,k in enumerate(sigs):
            itv.write(ids[i]+'\t'+sigs[i]+'\n')

all_test(data,design)
