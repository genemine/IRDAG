import os                 
import optparse
import numpy as np

optParser = optparse.OptionParser()
(opts, args) = optParser.parse_args()

# the input is IRFinder_output dir and  output path
IRFinder = args[0]
output = args[1]

def get_files(path, type):
    files = []
    for file in os.listdir(path):  
        file_path = os.path.join(path, file)  
        files.append(file_path + '/' + type) # get file full path
    return files

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn: 
        for l in fn: 
            l = l.split(sep)
            l[-1] = l[-1].split('\n')[0]
            read_data.append(l)
    return read_data[k:]

def get_all_data(files):
    samples = {}
    for file in files:
        id = file.split('/')[-2] # SRR id
        if os.path.exists(file) == True:
            data = read_file(file, 1)
            samples[id] = data
    return samples # all files

def screen(samples):
    IR = {}
    for id in samples:
        data = samples[id]
        temp = [] # temp IR event of single file
        for row in data:
            if row[20] == '-' or row[20] == 'NonUniformIntronCover': # maybe true IR event
                if float(row[7]) >= 0.7 and int(row[18]) >= 5 and float(row[19]) >= 0.1: # 8th:coverege 19th:reads number of flanking exon 20th: IR ratio
                    overlap = row[3].split('/')[-1].split('-') # overlapped with other features such as exon
                    if len(overlap) == 1: # keep clean
                        temp.append(row)
                    elif len(overlap) >= 2 and overlap[1] == 'near': # kepp anti-near
                        temp.append(row)
        IR[id] = temp # IR event of each file
    return IR

def get_union(IR, sep=';'):
    union = {}
    for key in IR:
        data = IR[key]
        for row in data:
            intron_id = row[1]+sep+row[2]+sep+row[3] 
            if union.get(intron_id,-1) == -1: 
                union[intron_id] = intron_id
            else:
                union[intron_id] = intron_id
    return union

def get_all_IR_ratio(samples,sep=';'):
    all_ratio = {}
    for file in samples:
        data = samples[file]
        temp = {} # IR ratio of each file
        for row in data:
            intron_id = row[1]+sep+row[2]+sep+row[3] 
            if temp.get(intron_id,-1) == -1: 
                temp[intron_id] = row[19]
            else: # should be not possible for this condition under IRFinder running
                temp[intron_id] = row[19]
        all_ratio[file] = temp # each file
    return all_ratio

def merge_samples(samples, IR):
    union_IR = get_union(IR) # IR list
    union_IR = sorted(union_IR)
    
    files = []
    for srr_id in samples:
        files.append(srr_id)
    files = sorted(files)

    IR_ratio = np.zeros( ( len(union_IR),len(files) ) )
    all_ratio = get_all_IR_ratio(samples)

    # get IR ratio of each intron
    for i,intron_id in enumerate(union_IR): # foreach all files
        for j,file in enumerate(files):
            data = all_ratio[file]
            if data.get(intron_id,-1) == -1: # cannot be true
                pass
            else:
                IR_ratio[i,j] = data[intron_id]

    return IR_ratio,union_IR,files

def write(IR_ratio, union_IR, files, output, sep='\t'):
    with open(output+'IRFinder_IR_ratio.txt','w') as fn:
        first_line = ['intron_id/sample']
        for file in files:
            first_line.append(file)
        first_line = sep.join(first_line) 
        fn.write(first_line+'\n')

        for i,ratio_values in enumerate(IR_ratio):
            line = [ union_IR[i] ]
            for ratio in ratio_values:
                line.append( str(ratio) ) 
            line = sep.join(line)
            fn.write(line+'\n')

def DE(IRFinder, output):
    files = get_files(IRFinder, 'IRFinder-IR-nondir.txt')
    samples = get_all_data(files)
    IR = screen(samples) # each file filtering
    IR_ratio,union_IR,files = merge_samples(samples, IR) # get format of DE input
    write(IR_ratio, union_IR, files, output)

DE(IRFinder, output)
