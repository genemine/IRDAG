import os       
import optparse
import numpy as np

optParser = optparse.OptionParser()
(opts, args) = optParser.parse_args()

# the input is iREAD_output dir and output path
iREAD = args[0]
output = args[1]

def get_files(path,type):
    files = []
    for file in os.listdir(path):  
        file_path = os.path.join(path, file)  
        files.append(file_path+'/'+type) # get file full path
    return files

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn: 
        for l in fn: 
            l = l.split(sep)
            l[-1] = l[-1].split('\n')[0]
            read_data.append(l)
    return read_data[k:]

def get_all_data(iREAD):
    samples = {} # all files
    for id in os.listdir(iREAD): # SRR_file id
        chrSet = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','X','Y']
        tk_data = {} # all chromosome the data of file
        for j in chrSet:
            file = iREAD+id+'/'+'overlap_'+j+'.bed.part'
            if os.path.exists(file) == True:
                data = read_file(file,1)
                for row in data:
                    intron_id = row[5]
                    if tk_data.get(intron_id,-1) == -1: 
                        tk_data[intron_id] = row[6] # read counts
                    else: # should be not possible for this condition under iREAD running
                        tk_data[intron_id] = row[6] # read counts

        samples[id] = tk_data # each file
    return samples

def screen(files):
    IR = {}
    for file in files:
        id = file.split('/')[-2] # SRR id
        temp = [] # temp IR event of single file
        data = read_file(file, 1)
        for row in data:
            if row[-1] == 'yes': # IR flag
                temp.append(row)
        IR[id] = temp # each file
    return IR

def get_union(IR):
    union = {}
    for key in IR: 
        data = IR[key]
        for row in data:
            intron_id = row[0]
            if union.get(intron_id,-1) == -1: 
                union[intron_id] = intron_id
            else:
                union[intron_id] = intron_id
    return union

def merge_samples(samples, IR):
    union_IR = get_union(IR)
    union_IR = sorted(union_IR)                                                                                         

    files = []
    for srr_id in samples:
        files.append(srr_id)
    files = sorted(files) 

    read_counts = np.zeros( ( len(union_IR),len(files) ) )

    # get read counts of each intron
    for i,intron_id in enumerate(union_IR): # foreach all files    
        for j,file in enumerate(files):
            data = samples[file]
            if data.get(intron_id,-1) == -1: 
                pass
            else:
                read_counts[i,j] = data[intron_id]
    return read_counts,union_IR,files

def write(all_counts, union_IR, files, output, sep='\t'):
    with open(output+'iREAD_read_counts.txt','w') as fn: 
        first_line = ['intron_id/sample']
        for file in files:
            first_line.append(file)
        first_line = sep.join(first_line) 
        fn.write(first_line+'\n')     
        
        for i,read_counts_row in enumerate(all_counts):
            line = [ union_IR[i] ]
            for read_counts in read_counts_row:
                line.append( str( int(read_counts) ) ) # because read_counts as input of edgeR, so need to convert int
            line = sep.join(line)
            fn.write(line+'\n')

def DE(iREAD, output):
    samples = get_all_data(iREAD) # read counts of all files
    files = get_files(iREAD, 'Aligned.sortedByCoord.out.ir.txt')
    IR = screen(files)
    
    read_counts,union_IR,files = merge_samples(samples, IR) # get format of DE input
    write(read_counts, union_IR, files, output)

DE(iREAD, output)
