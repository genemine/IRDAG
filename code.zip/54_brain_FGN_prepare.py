import os 
import copy

path = "/home/zhengjt/wuzhenpeng/BIBM/brain_FGN/"

def get_files(path):
    files = []
    for file in os.listdir(path): 
        file_path = os.path.join(path, file)  
        files.append(file_path)
    return files

def decompress(path):
    files = get_files(path+'network/')

    for file in files:
        os.system('unzip '+file+' -d '+path)

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn:      
        for l in fn: 
            l = l.split(sep)
            l[-1] = l[-1].split('\n')[0]
            read_data.append(l)
    return read_data[k:]

def get_brain(path):
    if not os.path.exists(path+'github/'):
        decompress(path)
    files = get_files(path+'github/')

    dict = {}
    for file in files:
        data = read_file(file)
        dict[file] = data

    nodes = set()
    e = 0
    with open(path+'brain_FGN_weight.txt','w') as bF:
        for file in dict:
            data = dict[file]
            for k in data:
                l = k[0].split(' ')
                r = k[1].split(' ')
                if len(l) == 1 and len(r) == 1 and k[0] != k[1]:
                    if len(l[0]) > 1 and len(r[0]) > 1:
                        bF.write(k[0]+'\t'+k[1]+'\t'+k[2]+'\n')
                    
                        nodes.add(k[0])
                        nodes.add(k[1])
                        e += 1

    print(len(nodes),e)
                                
get_brain(path)
