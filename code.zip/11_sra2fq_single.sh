# input is data path of single reads, output path

for i in $(ls $1)
do      
	fastq-dump $1$i --outdir $2
done
