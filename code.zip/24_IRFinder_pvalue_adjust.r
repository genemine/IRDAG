path =  "/home/zhengjt/wuzhenpeng/BIBM/DE_file_single/"
setwd(path)

x <- read.table("IRFinder_p_value.txt", sep = "\t", header = F, row.names = 1)

fdr <- 0.05 # adjusted p_value

# pvalue adjustment
p_value <- x[,1] # here 0 is not actual 0 ,just for p_value is too small

FDR <- p.adjust(p_value, "BH") 

intron_id <- rownames(x)

res <- cbind(intron_id, p_value, FDR) 

index <- as.numeric(res[,3]) < fdr
res_scr <- res[index,]

res_ss <- res_scr[order(res_scr[,3]),]
write.table(res_ss, file = "IRFinder_t_test.txt", quote = FALSE, sep = "\t", row.names = FALSE)

