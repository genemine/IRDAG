import os                 
import optparse

optParser = optparse.OptionParser()
(opts, args) = optParser.parse_args()

path = args[0]
method = args[1]

def get_files(path, type):
    files = []
    for file in os.listdir(path):  
        file_path = os.path.join(path, file)  
        files.append(file_path + '/' + type) # get file full path
    return files  

def rm_function(files):
    for file in files:
        os.system('rm '+file)

def rm_BAM(path):
    s1 = get_files(path, 'Aligned.toTranscriptome.out.bam')
    s2 = get_files(path, 'Aligned.sortedByCoord.out.bam')
    s3 = get_files(path, 'Aligned.out.bam')
    
    rm_function(s1)
    rm_function(s2)
    rm_function(s3)

def rm_IRFinder(path):
    s1 = get_files(path, 'unsorted.frag.bam')
    rm_function(s1)

def rm_iREAD(path):
    s1 = get_files(path, 'Aligned.sortedByCoord.out_bambed.bed')
    s2 = get_files(path, 'Aligned.sortedByCoord.out_overlap_initial.bed')

    rm_function(s1)
    rm_function(s2)

def rm_main(path, method):
    if method == 'BAM':
        rm_BAM(path)
    if method == 'IRFinder':
        rm_IRFinder(path)
    if method == 'iREAD':
        rm_iREAD(path)

rm_main(path, method)
