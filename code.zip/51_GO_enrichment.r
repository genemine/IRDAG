library('clusterProfiler')
library('org.Hs.eg.db')

# path and flag
setwd('/home/zhengjt/wuzhenpeng/BIBM/DE_file_single')
flag = "GO_single"

pdf_name = paste("../",flag,"/GO_enrichment.pdf", sep="")
pdf(pdf_name)

for(method in c( "IRDAG" )) {
	data <- read.table( paste(method,'_DE_name.txt', sep=""), header = F, sep="\t" )
	data <- as.character(data$V1)

	#test <- select(org.Hs.eg.db, keys = data, keytype = "SYMBOL", columns = c("ENTREZID"))
	#test <- na.omit(test)
	#nrow(test)

	eg <- bitr(data, fromType="SYMBOL", toType="ENTREZID", OrgDb="org.Hs.eg.db")
	eg <- na.omit(eg)
	#nrow(eg)

	ego_BP <- enrichGO( gene = eg[,2], 
						keyType = "ENTREZID", 
						OrgDb = "org.Hs.eg.db",
						ont = "BP", # BP,CC,MF and ALL
						minGSSize = 5,
						maxGSSize = 300, # more specific
						pAdjustMethod = "BH",
						pvalueCutoff = 0.05,
						qvalueCutoff = 0.05,
						readable = T)

	assign(method,ego_BP@result)       
	write.table(as.data.frame(ego_BP@result), file = paste("../",flag,"/GO_", method,".txt", sep = ""), quote = F, row.names = F, sep = "\t")

	d <- dotplot( ego_BP, 
				  title = method, 
				  showCategory = 15,
				  #x = ~GeneRatio / BgRatio
				  font.size = 10)
	print(d)
}

dev.off()
