# input is data path of paired reads, output path and building index of STAR

ulimit -n 10000

for i in $(ls $1)
do
{
	if [ ${i: 1-8: 1} == 1 ]; then
		temp=$i
	elif [ ${i: 1-8: 1} == 2 ]; then
		if [ ! -d $2${temp%_*}/ ];then
        	      mkdir -p $2${temp%_*}/
        fi
        
        
        STAR    --runThreadN 40 \
        	--readFilesIn $1$temp $1$i \
        	--quantMode TranscriptomeSAM GeneCounts \
       		--sjdbFileChrStartEnd $3sjdbList.out.tab \
        	--genomeDir $3 \
        	--outSAMtype BAM Unsorted SortedByCoordinate \
	        --outFileNamePrefix $2${temp%_*}/
	fi
}
done
wait
