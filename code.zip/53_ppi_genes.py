import numpy as np
import copy

file = './PPI_data/ppi_uniprotkb.txt'
map_tab = './PPI_data/map.tab' # from Uniprot Retrieve/ID mapping tool
ready_f = './PPI_data/ppi_ready.txt'
links_f = './PPI_data/links.txt'

def read_file(filename,k=0,sep='\t'):
    read_data = []
    with open(filename,'r') as fn: 
        for l in fn: 
            l = l.split(sep)
            read_data.append(l)
    return read_data[k:]

def get_ensembl_sin(uniprotkb_data, map_data):
    uni = set()
    for l in uniprotkb_data:
        uni.add(l[0])
        uni.add(l[1])
    uni = list(uni)
    
    all_dict = {}
    for k in uni:
        tmp = []
        for i,val in enumerate(map_data):
            if k == val[0]:
                tmp.append(val[1])
        all_dict[k] = tmp
    
    return all_dict

def convert_gene():
    uniprotkb_data = np.loadtxt(file,str,delimiter=' ')
    map_data = np.loadtxt(map_tab,str,delimiter='\t') 
    map_data = map_data[1:] 
    
    dict_uni = get_ensembl_sin(uniprotkb_data, map_data)
    
    links = set() # remove redundancy
    for k in uniprotkb_data:
        d1 = dict_uni[k[0]]
        d2 = dict_uni[k[1]]      
        for i in d1:
            for j in d2:
                links.add((i,j))

    ready = read_file(ready_f)
    for k in ready:
        links.add( (k[0], k[1]) )

    temp = copy.deepcopy(links) # remove self-intersecting
    for k in temp:
        if k[0] == k[1]:
            links.remove(k)
    
    nodes = set()
    for k in links:
        nodes.add(k[0])
        nodes.add(k[1])

    print(len(nodes),len(links))

    with open(links_f, 'w') as ou: 
        for l in links:
            ou.write(l[0]+'\t'+l[1]+'\t'+'1'+'\n')
    
convert_gene()

